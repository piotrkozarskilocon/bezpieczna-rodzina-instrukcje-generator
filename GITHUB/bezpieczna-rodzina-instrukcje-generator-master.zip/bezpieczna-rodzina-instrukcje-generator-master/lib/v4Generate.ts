/**
 * Shared logic for v4 (AI-first) project generation:
 * - Building the system + user prompts (deterministic from input)
 * - Validating the AI/imported JSON shape
 * - Bulk-inserting pages + elements into the gen4_* tables
 *
 * Lives in lib/ so both `generate` (auto) and `import` (manual) routes can
 * share it. Server-only — uses the Supabase admin client.
 */

import { getSupabaseAdmin } from "@/lib/supabase";
import {
  type DocumentType,
  type DeviceType,
  DOCUMENT_TYPE_LABELS,
  DEVICE_TYPE_LABELS,
  renderRequirementsForPrompt,
} from "@/lib/v4LegalTemplates";

export interface GenerationInput {
  name: string;
  model_code: string;
  model_name: string;
  features: Array<{ key: string; label: string; enabled: boolean }>;
  step_count: number;
  /** @deprecated — wynika teraz z document_type. Zostawione, bo starsze projekty mają je w ai_input. */
  warranty_mode: "full" | "short" | "none";
  page_size_mm: { width: number; height: number };
  /** Typ tworzonego dokumentu (QSG, KG, pełna instrukcja). Determinuje listę wymaganych sekcji. */
  document_type: DocumentType;
  /** Typ urządzenia — wpływa na sekcje device-specific (RODO dziecka, zastrzeżenia medyczne, IP rating). */
  device_type: DeviceType;
}

export interface GeneratedProject {
  pages: Array<{
    template: string;
    page_number: number;
    width_mm: number;
    height_mm: number;
    title: string | null;
    elements: Array<{
      type: string;
      x_mm: number;
      y_mm: number;
      w_mm: number;
      h_mm: number;
      z_index?: number;
      properties: Record<string, unknown>;
    }>;
  }>;
}

const VALID_TEMPLATES = new Set([
  "blank", "cover", "toc", "step", "warranty_terms", "warranty_stamp", "contact",
]);
const VALID_TYPES = new Set([
  "text", "image", "line", "rect", "qr", "page_number", "callout",
]);

export async function loadGlossaryDoNotTranslate(): Promise<string[]> {
  const sb = getSupabaseAdmin();
  const { data } = await sb
    .from("gen3_glossary")
    .select("source_term")
    .eq("do_not_translate", true);
  return (data ?? []).map((g) => g.source_term);
}

export interface ProjectImageInfo {
  id: string;
  description: string | null;
  preferred_page_id: string | null;
  preferred_page_number: number | null;
  mime_type: string | null;
  width_px: number | null;
  height_px: number | null;
}

/** Lista obrazków projektu z opisami i preferowanymi stronami — dorzucana
 *  do każdego prompta AI by Claude mógł wybrać image_id zamiast wymyślania. */
export async function loadProjectImages(projectId: string): Promise<ProjectImageInfo[]> {
  const sb = getSupabaseAdmin();
  const { data } = await sb
    .from("gen4_images")
    .select(`
      id, description, preferred_page_id, mime_type, width_px, height_px,
      preferred_page:gen4_pages!preferred_page_id(page_number)
    `)
    .eq("project_id", projectId)
    .order("created_at", { ascending: false });
  if (!data) return [];
  return data.map((row) => {
    const pp = row.preferred_page as { page_number?: number } | { page_number?: number }[] | null;
    const pageNumber =
      pp && Array.isArray(pp) ? pp[0]?.page_number ?? null
        : pp && typeof pp === "object" ? (pp.page_number ?? null)
        : null;
    return {
      id: row.id,
      description: row.description,
      preferred_page_id: row.preferred_page_id,
      preferred_page_number: pageNumber,
      mime_type: row.mime_type,
      width_px: row.width_px,
      height_px: row.height_px,
    };
  });
}

/** Renderuje listę obrazków dla prompta. `currentPageNumber` — jeśli podany,
 *  podkreślamy które obrazki mają tę stronę jako preferowaną. */
export function renderImagesForPrompt(
  images: ProjectImageInfo[],
  currentPageNumber?: number,
): string {
  if (images.length === 0) {
    return [
      "DOSTĘPNE OBRAZKI W BIBLIOTECE PROJEKTU:",
      "(biblioteka jest pusta — nie wstawiaj elementów type='image')",
    ].join("\n");
  }
  const lines: string[] = [
    "DOSTĘPNE OBRAZKI W BIBLIOTECE PROJEKTU:",
    "Jeśli któryś z poniższych obrazków pasuje do treści tej strony, wstaw go",
    "jako element type='image' z properties.image_id wskazującym jego id.",
    "REGUŁY:",
    "- Jeśli obraz ma 'preferowana strona' = TA STRONA → WSTAW GO.",
    "- Jeśli opis obrazka pasuje do tematu strony → WSTAW GO (Twoja decyzja).",
    "- NIE WYMYŚLAJ image_id, NIE wstawiaj obrazków spoza tej listy.",
    "- Rozmiar elementu image (w_mm × h_mm): typowo 30x30 do 60x40 mm dla",
    "  screenshotów aplikacji, 30x40 do 50x50 mm dla zdjęć urządzenia.",
    "- Zostaw miejsce wokół obrazka na tekst (~3 mm marginesu).",
    "- Schemat: { type:'image', x_mm, y_mm, w_mm, h_mm, properties:{ image_id, fit_mode:'contain' } }",
    "",
    "Lista:",
  ];
  for (const img of images) {
    const prefMark =
      img.preferred_page_number != null && img.preferred_page_number === currentPageNumber
        ? "  ⭐ PREFEROWANY DLA TEJ STRONY"
        : img.preferred_page_number != null
          ? `  preferowana strona: ${img.preferred_page_number}`
          : "  preferowana strona: (brak — AI sam decyduje)";
    lines.push(`- id: "${img.id}"`);
    lines.push(`  opis: ${img.description ? `"${img.description}"` : "(BRAK OPISU — pomiń jeśli nie pasuje do kontekstu)"}`);
    lines.push(prefMark);
  }
  return lines.join("\n");
}

/** Returns the project's active design system: default row from
 *  gen4_design_systems if any, otherwise the legacy gen4_projects.design_system
 *  column, otherwise null. */
export async function loadProjectDesignSystem(
  projectId: string,
): Promise<Record<string, unknown> | null> {
  const sb = getSupabaseAdmin();
  // 1) Default row in the new table.
  const { data: defaultDs } = await sb
    .from("gen4_design_systems")
    .select("content")
    .eq("project_id", projectId)
    .eq("is_default", true)
    .maybeSingle();
  if (defaultDs?.content && typeof defaultDs.content === "object") {
    return defaultDs.content as Record<string, unknown>;
  }
  // 2) Legacy column.
  const { data: proj } = await sb
    .from("gen4_projects")
    .select("design_system")
    .eq("id", projectId)
    .single();
  return (proj?.design_system as Record<string, unknown> | null) ?? null;
}

export interface DocumentScope {
  document_type: DocumentType;
  device_type: DeviceType;
  step_count?: number;
}

export function buildSystemPrompt(
  doNotTranslate: string[],
  designSystem?: Record<string, unknown> | null,
  scope?: DocumentScope | null,
): string {
  const requirements = scope
    ? renderRequirementsForPrompt(scope.document_type, scope.device_type, scope.step_count ?? 1)
    : null;
  return [
    "Jesteś asystentem generującym strukturalne instrukcje obsługi (QSG + Karta Gwarancyjna)",
    "dla urządzeń marki Locon (Bezpieczna Rodzina). Każda instrukcja jest drukowana",
    "w formacie 76×76 mm, w skali szarości, na cienkim papierze.",
    ...(designSystem
      ? [
          "",
          "DESIGN SYSTEM (priorytet — używaj poniższych tokenów spójnie):",
          "```json",
          JSON.stringify(designSystem, null, 2),
          "```",
          "Trzymaj się kolorów, czcionek, spacing i guidelines z design systemu.",
          "Jeśli design system nie określa czegoś, korzystaj z zasad poniżej.",
        ]
      : []),
    "",
    "Zasady językowe:",
    "- Język bazowy generacji: POLSKI. Zwracaj treść tylko po polsku.",
    "- BEZWZGLĘDNIE używaj poprawnych polskich znaków diakrytycznych:",
    "  ą ć ę ł ń ó ś ź ż / Ą Ć Ę Ł Ń Ó Ś Ź Ż.",
    '  Pisz \'Skrócona instrukcja obsługi\' - NIE \'Skrocona instrukcja obslugi\'.',
    '  Pisz \'Włóż\', \'Naładuj\', \'Załóż konto\' - NIE \'Wloz\', \'Naladuj\', \'Zaloz\'.',
    "  W odpowiedzi JSON używaj surowych znaków UTF-8, nie sekwencji \\uXXXX.",
    "- NIE TŁUMACZ ani nie zmieniaj poniższych terminów (zostawiaj dosłownie):",
    doNotTranslate.map((t) => `  - ${t}`).join("\n"),
    "- Nie tłumacz adresów URL, kodów modeli (GJD.XX), nazwy firmy Locon Sp. z o.o.",
    "",
    "Zasady layoutu:",
    "- Strona ma marginesy ~3 mm od każdej krawędzi.",
    "- Czcionki w punktach (pt). Nagłówki: 11-14pt, body: 6-8pt, podpisy: 4-5pt.",
    "- Kolory grayscale: tekst #0f172a, accent #475569, jasny #94a3b8.",
    "- Numeracja stron: zawsze element typu page_number z formatem '{LANG} {n}/{N}'",
    "  w prawym dolnym rogu każdej strony, font 4-5pt.",
    "",
    "Tytuły stron i spis treści (BEZWZGLĘDNIE):",
    "- Każda strona musi mieć pole `title` (krótki nagłówek strony, max ~40 znaków).",
    "- Wyjątek: strona z `template: cover` ma `title: null` (okładka nie potrzebuje tytułu).",
    "- DRUGA strona w dokumencie (zaraz po cover) MUSI być template `toc` ze",
    "  `title: 'Spis treści'`. Wygeneruj jej elementy jako numerowaną listę",
    "  pozostałych stron z ich tytułami i numerami (np. `2. Pierwsze uruchomienie ........ 3`).",
    "  Spis treści NIE wymienia samego siebie ani okładki.",
    "- Pole `title` MUSI też pojawić się jako widoczny nagłówek strony w `elements`",
    "  (zwykle text na górze strony, font 11-14pt). W ten sposób edytor może bocznym",
    "  panelem nawigacji pokazać tytuł identyczny z tym na wydruku.",
    "",
    "Format odpowiedzi:",
    "ZAPISZ wynik jako ARTEFAKT (artifact) typu `application/json` o nazwie",
    "`instrukcja.json` — dzięki temu użytkownik może go skopiować lub pobrać",
    "jednym kliknięciem zamiast zaznaczać tekst w oknie czatu.",
    "W treści artefaktu umieść WYŁĄCZNIE poprawny JSON (bez komentarzy, bez ``` fence)",
    "zgodnie ze schematem:",
    "{",
    "  \"pages\": [",
    "    {",
    "      \"template\": \"cover|toc|step|warranty_terms|warranty_stamp|contact|blank\",",
    "      \"page_number\": 1,",
    "      \"width_mm\": 76,",
    "      \"height_mm\": 76,",
    "      \"title\": \"Pierwsze uruchomienie\",   // null tylko dla cover",
    "      \"elements\": [",
    "        {",
    "          \"type\": \"text|image|line|rect|qr|page_number|callout\",",
    "          \"x_mm\": 5, \"y_mm\": 8, \"w_mm\": 66, \"h_mm\": 8,",
    "          \"z_index\": 0,",
    "          \"properties\": {",
    "            // text/callout: { content, font_size_pt, color, align: 'left|center|right' }",
    "            // line/rect:    { stroke_width, color, fill (rect only) }",
    "            // qr:           { url }",
    "            // page_number:  { format: '{LANG} {n}/{N}', font_size_pt }",
    "            // image:        { image_id, fit_mode } (image_id null — biblioteka pusta)",
    "          }",
    "        }",
    "      ]",
    "    }",
    "  ]",
    "}",
    "",
    ...(requirements
      ? [requirements]
      : [
          "Struktura instrukcji (kolejność stron — sztywna):",
          "1. Cover (template=cover, title=null) — logo Bezpieczna Rodzina, model name + code,",
          "   podtytuł, wersja 003.",
          "2. Spis treści (template=toc, title='Spis treści') — lista pozostałych stron",
          "   z numerami (np. text element z treścią 'Pierwsze uruchomienie .... 3').",
          "3-N. Step — kolejne kroki uruchomienia (zgodnie z step_count z inputu),",
          "     każdy z własnym `title` (np. 'Naładuj zegarek', 'Włóż kartę SIM',",
          "     'Załóż konto w aplikacji').",
          "Następnie: warranty_terms (title='Warunki gwarancji', jeśli warranty_mode=full|short),",
          "warranty_stamp (title='Karta gwarancyjna'), contact (title='Kontakt').",
        ]),
    "",
    "Każdy element musi mieścić się w obszarze strony (uwzględnij marginesy).",
    "Bądź zwięzły i konkretny w treści — to drukowana instrukcja, nie marketing.",
    "Brakujące dane konkretne (numery, wartości techniczne, normy, IMEI, NIP) zostaw",
    "jako widoczne placeholdery — NIE WYMYŚLAJ ich. Lepiej '⚠️ DO UZUPEŁNIENIA: ...'",
    "niż błędna liczba która trafi do druku.",
  ].join("\n");
}

/**
 * Krótki prompt który prosi AI o zwrócenie TYLKO szkieletu stron — bez elements.
 * Wynik: lista { template, page_number, title } gotowa do bulkInsertSkeletonPages.
 * Używamy w wizardzie generate, by zmieścić się w 60s Hobby cap. Elements
 * dorabiamy osobnymi krótkimi wywołaniami per strona.
 */
export function buildSkeletonSystemPrompt(
  scope: DocumentScope,
): string {
  return [
    "Jesteś asystentem generującym SZKIELET drukowanego dokumentu (lista stron, bez elementów).",
    "Każdy dokument ma sztywną strukturę wynikającą z wymagań prawnych — Twoja praca:",
    "wygenerować listę stron z tytułami i template'ami zgodną z listą wymagań poniżej.",
    "",
    renderRequirementsForPrompt(scope.document_type, scope.device_type, scope.step_count ?? 1),
    "",
    "Format odpowiedzi — KRYTYCZNE:",
    "Zwróć WYŁĄCZNIE surowy JSON. Twoja odpowiedź MUSI zacząć się od znaku `{`",
    "i skończyć znakiem `}`. ZAKAZANE:",
    "- otaczanie odpowiedzi markdown fence ``` ani ```json",
    "- żadne wprowadzenie typu 'Oto JSON:' / 'Here is the structure:'",
    "- żadne komentarze, podsumowanie ani opisy PRZED ani PO JSON-ie",
    "- żadne dodatkowe pola w obiekcie strony (TYLKO template, page_number, title)",
    "",
    "Schemat (zwróć dokładnie tę strukturę):",
    "{",
    '  "pages": [',
    '    { "template": "cover", "page_number": 1, "title": null },',
    '    { "template": "toc", "page_number": 2, "title": "Spis treści" },',
    '    { "template": "step", "page_number": 3, "title": "Pierwsze uruchomienie" }',
    "  ]",
    "}",
    "Nie generuj `elements` — w tym wywołaniu chcemy tylko szkielet.",
    "Tytuły muszą być w POLSKIM z pełnymi znakami diakrytycznymi (ą ć ę ł ń ó ś ź ż).",
    "Surowy UTF-8 w JSON, nie sekwencje \\uXXXX.",
  ].join("\n");
}

export function buildSkeletonUserPrompt(input: GenerationInput): string {
  return [
    `Wygeneruj szkielet dokumentu ${DOCUMENT_TYPE_LABELS[input.document_type]}`,
    `dla urządzenia: ${DEVICE_TYPE_LABELS[input.device_type]}.`,
    "",
    `Model (DOKŁADNIE JEDEN — nie mieszaj z innymi): ${input.model_name} (${input.model_code}).`,
    `Liczba kroków pierwszego uruchomienia (orientacyjnie): ${input.step_count}.`,
    "",
    "Zwróć kompletną listę stron zgodną z wymaganiami prawnymi (Cover → TOC → reszta).",
    "Tytuły stron pisz w kontekście tego konkretnego modelu, bez wymieniania innych kodów GJD.XX.",
  ].join("\n");
}

export interface SkeletonPage {
  template: string;
  page_number: number;
  title: string | null;
}

export function validateSkeletonGenerated(data: unknown): SkeletonPage[] {
  if (!data || typeof data !== "object" || !("pages" in data)) {
    throw new Error("response missing 'pages' field");
  }
  const pages = (data as { pages: unknown }).pages;
  if (!Array.isArray(pages) || pages.length === 0) {
    throw new Error("'pages' must be a non-empty array");
  }
  const out: SkeletonPage[] = [];
  for (let i = 0; i < pages.length; i++) {
    const p = pages[i] as Record<string, unknown>;
    const template =
      typeof p.template === "string" && VALID_TEMPLATES.has(p.template) ? p.template : "blank";
    let title: string | null = null;
    if (template !== "cover" && typeof p.title === "string" && p.title.trim()) {
      title = p.title.trim();
    }
    out.push({
      template,
      page_number: typeof p.page_number === "number" ? p.page_number : i + 1,
      title,
    });
  }
  return out;
}

/** Bulk-insert szkielet stron (bez elementów). Idempotentne — robić po
 *  wcześniejszym wipie gen4_pages dla projektu. */
export async function bulkInsertSkeletonPages(
  projectId: string,
  pages: SkeletonPage[],
): Promise<{ pages: number }> {
  const sb = getSupabaseAdmin();
  const rows = pages.map((p) => ({
    project_id: projectId,
    page_number: p.page_number,
    width_mm: 76,
    height_mm: 76,
    template: p.template,
    title: p.title,
  }));
  const { error } = await sb.from("gen4_pages").insert(rows);
  if (error) throw new Error(error.message);
  return { pages: rows.length };
}

export function buildUserPrompt(input: GenerationInput): string {
  const features = input.features.filter((f) => f.enabled).map((f) => `- ${f.label}`).join("\n");
  const lines: string[] = [];
  if (input.document_type && input.device_type) {
    lines.push(`Wygeneruj dokument typu: ${DOCUMENT_TYPE_LABELS[input.document_type]}`);
    lines.push(`Dla urządzenia: ${DEVICE_TYPE_LABELS[input.device_type]}`);
  } else {
    lines.push("Wygeneruj instrukcję obsługi dla urządzenia:");
  }
  lines.push("");
  lines.push(`Nazwa: ${input.model_name}`);
  lines.push(`Kod modelu: ${input.model_code}`);
  lines.push(`Funkcje:`);
  lines.push(features || "- (brak)");
  lines.push("");
  lines.push(`Liczba kroków uruchomienia (orientacyjnie): ${input.step_count}`);
  lines.push(`Format strony: ${input.page_size_mm.width}×${input.page_size_mm.height} mm`);
  lines.push("");
  lines.push("Zwróć kompletny JSON ze strukturą wszystkich stron i elementów,");
  lines.push("zgodnie z listą wymaganych sekcji w prompcie systemowym (jeśli została podana —");
  lines.push("kolejność i tytuły są wiążące).");
  return lines.join("\n");
}

/** Soft-validate a parsed JSON tree as a GeneratedProject. Coerces missing
 *  fields to defaults, drops unknown element types — never throws on a
 *  semantically valid input. Caller should still try/catch JSON.parse. */
export function validateGenerated(data: unknown): GeneratedProject {
  if (!data || typeof data !== "object" || !("pages" in data)) {
    throw new Error("response missing 'pages' field");
  }
  const pages = (data as { pages: unknown }).pages;
  if (!Array.isArray(pages) || pages.length === 0) {
    throw new Error("'pages' must be a non-empty array");
  }
  const out: GeneratedProject = { pages: [] };
  for (let i = 0; i < pages.length; i++) {
    const p = pages[i] as Record<string, unknown>;
    const template =
      typeof p.template === "string" && VALID_TEMPLATES.has(p.template) ? p.template : "blank";
    // Cover: title forced to null. Other pages: take whatever the AI sent;
    // null is allowed (importer doesn't reject it — sidebar shows fallback).
    let title: string | null = null;
    if (template !== "cover") {
      if (typeof p.title === "string" && p.title.trim()) {
        title = p.title.trim();
      }
    }
    const page = {
      template,
      page_number: typeof p.page_number === "number" ? p.page_number : i + 1,
      width_mm: typeof p.width_mm === "number" ? p.width_mm : 76,
      height_mm: typeof p.height_mm === "number" ? p.height_mm : 76,
      title,
      elements: [] as GeneratedProject["pages"][number]["elements"],
    };
    const elements = Array.isArray(p.elements) ? p.elements : [];
    for (const e of elements) {
      const el = e as Record<string, unknown>;
      if (!VALID_TYPES.has(String(el.type))) continue;
      page.elements.push({
        type: String(el.type),
        x_mm: typeof el.x_mm === "number" ? el.x_mm : 0,
        y_mm: typeof el.y_mm === "number" ? el.y_mm : 0,
        w_mm: typeof el.w_mm === "number" ? el.w_mm : 10,
        h_mm: typeof el.h_mm === "number" ? el.h_mm : 5,
        z_index: typeof el.z_index === "number" ? el.z_index : 0,
        properties: (el.properties && typeof el.properties === "object")
          ? (el.properties as Record<string, unknown>)
          : {},
      });
    }
    out.pages.push(page);
  }
  return out;
}

/** Bulk-insert pages + elements for a project. All elements get origin='ai'.
 *  Pages are looked up by page_number after insert so we can map elements. */
export async function bulkInsertGeneratedProject(
  projectId: string,
  parsed: GeneratedProject,
): Promise<{ pages: number; elements: number }> {
  const sb = getSupabaseAdmin();

  const pageRows = parsed.pages.map((p) => ({
    project_id: projectId,
    page_number: p.page_number,
    width_mm: p.width_mm,
    height_mm: p.height_mm,
    template: p.template,
    title: p.title,
  }));

  const { data: insertedPages, error: pagesErr } = await sb
    .from("gen4_pages")
    .insert(pageRows)
    .select("id, page_number");
  if (pagesErr || !insertedPages) {
    throw new Error(pagesErr?.message ?? "pages insert failed");
  }
  const pageIdByNumber = new Map<number, string>();
  for (const row of insertedPages) pageIdByNumber.set(row.page_number, row.id);

  const elementRows: Array<Record<string, unknown>> = [];
  for (const p of parsed.pages) {
    const pageId = pageIdByNumber.get(p.page_number);
    if (!pageId) continue;
    p.elements.forEach((el, idx) => {
      elementRows.push({
        page_id: pageId,
        type: el.type,
        x_mm: el.x_mm,
        y_mm: el.y_mm,
        w_mm: el.w_mm,
        h_mm: el.h_mm,
        z_index: el.z_index ?? idx,
        properties: el.properties,
        origin: "ai",
      });
    });
  }

  if (elementRows.length > 0) {
    const CHUNK = 500;
    for (let i = 0; i < elementRows.length; i += CHUNK) {
      const slice = elementRows.slice(i, i + CHUNK);
      const { error } = await sb.from("gen4_elements").insert(slice);
      if (error) throw new Error(error.message);
    }
  }

  return { pages: parsed.pages.length, elements: elementRows.length };
}

/** Strips an optional ```json ... ``` fence and JSON.parse. Tolerates raw
 *  control characters inside string literals (a common artefact when copying
 *  multi-line LLM output through terminals / markdown viewers — they leave
 *  literal newlines inside what should be \\n-escaped).
 *
 *  Strategy (4 próby — każda kolejna bardziej tolerancyjna):
 *    1. Strict parse na trimmie.
 *    2. Usuń otwierający i zamykający fence ```/```json niezależnie (regex
 *       non-anchored), parse.
 *    3. Auto-escape control chars w stringach, parse.
 *    4. Wytnij od pierwszej `{` do ostatniej `}` (lub `[` ... `]` jeśli
 *       odpowiedź to tablica), parse. Ostatnia deska ratunku gdy AI okrasił
 *       JSON dodatkową prozą ("Oto JSON:\n```json {...}```\nMam nadzieję...").
 */
export function parseJsonFromAi<T = unknown>(text: string): T {
  const raw = text.trim();

  // Próba 1: strict parse jak jest.
  try {
    return JSON.parse(raw) as T;
  } catch { /* idziemy dalej */ }

  // Próba 2: zdejmij fence agresywnie (otwierający + zamykający, niezależnie).
  const noFence = raw
    .replace(/^```(?:json|JSON)?\s*\n?/, "")
    .replace(/\n?\s*```\s*$/, "")
    .trim();
  try {
    return JSON.parse(noFence) as T;
  } catch { /* idziemy dalej */ }

  // Próba 3: escape control chars w stringach.
  const sanitized = escapeControlCharsInStrings(noFence);
  try {
    return JSON.parse(sanitized) as T;
  } catch { /* idziemy dalej */ }

  // Próba 4: wyrwij pierwszy { ... } z całego tekstu (działa gdy AI dodał
  // prozę przed/po JSON-ie albo zostawił niesymetryczne fence).
  const firstObj = raw.indexOf("{");
  const lastObj = raw.lastIndexOf("}");
  const firstArr = raw.indexOf("[");
  const lastArr = raw.lastIndexOf("]");
  let extracted: string | null = null;
  if (firstObj !== -1 && lastObj > firstObj) {
    extracted = raw.slice(firstObj, lastObj + 1);
  } else if (firstArr !== -1 && lastArr > firstArr) {
    extracted = raw.slice(firstArr, lastArr + 1);
  }
  if (extracted) {
    try {
      return JSON.parse(extracted) as T;
    } catch {
      try {
        return JSON.parse(escapeControlCharsInStrings(extracted)) as T;
      } catch { /* dalej */ }
    }
  }

  // Próba 5: napraw obcięty JSON. Sytuacja: Haiku skończył tokeny w środku
  // tablicy elements [...], zostawiając niedomkniętą strukturę. Robimy walk
  // śledzący stack ([, {, ") i ucinamy do ostatniej pozycji gdzie ostatni
  // ELEMENT tablicy/obiektu zamknął się czysto, potem zamykamy pozostały
  // stack odwrotnie. Działa zarówno na `noFence` jak i na surowy `raw`.
  for (const candidate of [noFence, raw]) {
    const repaired = repairTruncatedJson(candidate);
    if (repaired) {
      try {
        return JSON.parse(repaired) as T;
      } catch {
        try {
          return JSON.parse(escapeControlCharsInStrings(repaired)) as T;
        } catch { /* finalne wyrzucenie poniżej */ }
      }
    }
  }

  const preview = raw.slice(0, 400);
  const tail = raw.slice(-200);
  throw new Error(
    `failed to parse JSON after 5 attempts (fence-strip + control-char-escape + bracket-extract + truncation-repair)\nPreview: ${preview}\n...\nTail: ${tail}`,
  );
}

/** Próbuje naprawić JSON który został obcięty w środku (limit output tokens
 *  z modelu, kill connection itd.). Walk char-by-char śledzi stack otwartych
 *  brackets/braces oraz stringi, i wyznacza najpóźniejszą pozycję gdzie da się
 *  bezpiecznie ZAMKNĄĆ wszystko co zostało otwarte. Zwraca naprawiony string
 *  lub `null` jeśli się nie da. */
function repairTruncatedJson(input: string): string | null {
  if (!input) return null;
  // Zacznij od pierwszego sensownego znaku otwierającego.
  const firstOpen = (() => {
    const o = input.indexOf("{");
    const a = input.indexOf("[");
    if (o === -1) return a;
    if (a === -1) return o;
    return Math.min(o, a);
  })();
  if (firstOpen === -1) return null;
  const s = input.slice(firstOpen);

  const stack: string[] = []; // "{" | "[" | "\""
  let lastSafeCut = -1; // pozycja PO ostatnim zamknięciu obiektu/tablicy gdy depth >= 1
  let i = 0;
  while (i < s.length) {
    const ch = s[i];
    const top = stack[stack.length - 1];
    if (top === "\"") {
      if (ch === "\\") {
        i += 2; // pomiń escape'owany znak
        continue;
      }
      if (ch === "\"") {
        stack.pop();
      }
      i++;
      continue;
    }
    if (ch === "\"") {
      stack.push("\"");
      i++;
      continue;
    }
    if (ch === "{" || ch === "[") {
      stack.push(ch);
      i++;
      continue;
    }
    if (ch === "}" || ch === "]") {
      const expected = ch === "}" ? "{" : "[";
      if (top === expected) {
        stack.pop();
        // Jeśli wewnątrz tablicy/obiektu (depth >= 1), zapisz pozycję jako
        // bezpieczny punkt cięcia — wszystko do tu jest poprawnym prefiksem.
        if (stack.length >= 1) {
          lastSafeCut = i + 1;
        }
      } else {
        // niezgodność — brak naprawy
        return null;
      }
      i++;
      continue;
    }
    i++;
  }

  // Jeśli stack pusty → JSON kompletny, nie ma czego naprawiać (ale parse
  // wcześniej się wywalił, więc problem nie jest truncacją). Zwracamy null.
  if (stack.length === 0) return null;
  // Potrzebujemy choć jednego zamkniętego elementu w środku — w przeciwnym
  // razie tablica byłaby pusta i nie ma sensu kontynuować.
  if (lastSafeCut === -1) return null;

  // Odetnij do ostatniego bezpiecznego cięcia, usuń trailing przecinek/whitespace,
  // i zamknij pozostałe brackety odwrotnie.
  let head = s.slice(0, lastSafeCut).replace(/[\s,]+$/, "");
  // Z tej pozycji w PRZÓD przeparsuj jeszcze raz tylko żeby ustalić aktualny
  // stack — bo lastSafeCut to pozycja ze stack-em "po cięciu" historycznie, ale
  // zachowaliśmy stan z tej pozycji. Bezpieczniej: ponownie przejdź head.
  const repairStack: string[] = [];
  let j = 0;
  while (j < head.length) {
    const ch = head[j];
    const top = repairStack[repairStack.length - 1];
    if (top === "\"") {
      if (ch === "\\") { j += 2; continue; }
      if (ch === "\"") repairStack.pop();
      j++;
      continue;
    }
    if (ch === "\"") { repairStack.push("\""); j++; continue; }
    if (ch === "{" || ch === "[") { repairStack.push(ch); j++; continue; }
    if (ch === "}" || ch === "]") { repairStack.pop(); j++; continue; }
    j++;
  }
  // Zamknij stack odwrotnie.
  while (repairStack.length > 0) {
    const open = repairStack.pop();
    head += open === "{" ? "}" : open === "[" ? "]" : "\"";
  }
  return head;
}

/** Walks the input one char at a time, tracking whether we're inside a
 *  string literal, and replaces raw control characters (newlines, tabs,
 *  carriage returns, other 0x00-0x1F) with their JSON-escaped form. Outside
 *  of strings the input is preserved verbatim, so syntactic whitespace is
 *  untouched. */
function escapeControlCharsInStrings(raw: string): string {
  let out = "";
  let inString = false;
  let escapeNext = false;
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (escapeNext) {
      out += ch;
      escapeNext = false;
      continue;
    }
    if (inString && ch === "\\") {
      out += ch;
      escapeNext = true;
      continue;
    }
    if (ch === '"') {
      inString = !inString;
      out += ch;
      continue;
    }
    if (inString) {
      if (ch === "\n") { out += "\\n"; continue; }
      if (ch === "\r") { out += "\\r"; continue; }
      if (ch === "\t") { out += "\\t"; continue; }
      const code = ch.charCodeAt(0);
      if (code < 0x20) {
        out += "\\u" + code.toString(16).padStart(4, "0");
        continue;
      }
    }
    out += ch;
  }
  return out;
}
